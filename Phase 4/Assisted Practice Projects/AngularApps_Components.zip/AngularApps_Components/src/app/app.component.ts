import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<product-list></product-list>',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularApps_Components';
}
